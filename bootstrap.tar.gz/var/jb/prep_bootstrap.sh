#!/var/jb/bin/sh

/var/jb/Library/dpkg/info/darwintools.postinst
/var/jb/Library/dpkg/info/system-cmds.postinst
/var/jb/Library/dpkg/info/debianutils.postinst configure 99999
/var/jb/Library/dpkg/info/apt.postinst configure 999999
/var/jb/Library/dpkg/info/zsh.postinst configure 999999
/var/jb/Library/dpkg/info/bash.postinst configure 999999
/var/jb/Library/dpkg/info/vi.postinst configure 999999

/var/jb/usr/sbin/pwd_mkdb -p /var/jb/etc/master.passwd

/var/jb/usr/bin/chsh -s /var/jb/usr/bin/zsh mobile
/var/jb/usr/bin/chsh -s /var/jb/usr/bin/zsh root

rm -f /var/jb/prep_bootstrap.sh
